SELECT disease, COUNT(*) AS soni
FROM Bemorlar
GROUP BY disease
ORDER BY soni DESC
LIMIT 1;

SELECT *
FROM Bemorlar
WHERE age > 40
  AND isMarried = 1
  AND gender = 'Erkak';

SELECT disease
FROM Bemorlar
WHERE age < 30
  AND isMarried = 0
  AND gender = 'Ayol';
  
  SELECT gender, COUNT(*) AS soni
FROM Bemorlar
GROUP BY gender;

SELECT *
FROM Bemorlar
WHERE age < 40
  AND disease = 'Qandli diabet'
ORDER BY age DESC;



