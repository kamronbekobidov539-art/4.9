CREATE TABLE Meva (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nomi VARCHAR(50),
    narxi INT,
    navi VARCHAR(50)
);

INSERT INTO Meva (nomi, narxi, navi) VALUES
('Olma', 12000, 'Golden'),
('Banan', 25000, 'Ekvador'),
('Anor', 30000, 'Shirin'),
('Uzum', 18000, 'Qora'),
('Shaftoli', 22000, 'Oq'),
('Gilos', 45000, 'Qizil'),
('Ananas', 50000, 'Tropik'),
('Mandarin', 15000, 'Abxaz'),
('Apelsin', 17000, 'Misr'),
('Olcha', 20000, 'Yovvoyi');

SELECT *
FROM Meva
WHERE narxi BETWEEN 10000 AND 50000;

SELECT *
FROM Meva
ORDER BY LENGTH(nomi), narxi DESC;

