CREATE TABLE Aeroport (
    id INT AUTO_INCREMENT PRIMARY KEY,
    samolyot_turi VARCHAR(50),
    uchish_sanasi DATE,
    uchish_shahri VARCHAR(50),
    qonish_shahri VARCHAR(50),
    uchish_vaqti TIME
);

INSERT INTO Aeroport (samolyot_turi, uchish_sanasi, uchish_shahri, qonish_shahri, uchish_vaqti) VALUES
('Boeing 737', '2025-03-15', 'Samarqand', 'Toshkent', '15:30'),
('Airbus A320', '2025-04-10', 'Buxoro', 'Toshkent', '16:45'),
('Boeing 777', '2025-05-20', 'Urganch', 'Seul', '10:00'),
('Airbus A330', '2025-06-01', 'Toshkent', 'London', '22:00'),
('Boeing 737', '2025-02-10', 'Fargona', 'Toshkent', '14:30'),
('ATR 72', '2025-03-25', 'Namangan', 'Toshkent', '17:00'),
('Airbus A320', '2025-04-05', 'Toshkent', 'Dubai', '09:00'),
('Boeing 787', '2025-07-15', 'Toshkent', 'New York', '08:00'),
('ATR 72', '2025-05-05', 'Andijon', 'Toshkent', '18:30'),
('Boeing 737', '2025-03-01', 'Qarshi', 'Moskva', '13:00');

SELECT *
FROM Aeroport
WHERE MONTH(uchish_sanasi) IN (3, 4, 5);

DELETE FROM Aeroport
WHERE uchish_vaqti BETWEEN '14:00:00' AND '18:00:00'
AND qonish_shahri = 'Toshkent';


